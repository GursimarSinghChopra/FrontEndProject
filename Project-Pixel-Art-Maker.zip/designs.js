var height, width, colour;
$('#sizePicker').submit(function(event) {
    event.preventDefault();
    height = $('#inputHeight').val();
    width = $('#inputWeight').val();
    makeGrid(height, width);
})
// grid generation based on user input
function makeGrid(a, b) {
    $('tr').remove();
    for (var i = 0; i < a; i++) {
        $('#pixelCanvas').append('<tr id =tt' + i + '></tr>');
        for (var j = 0; j < b; j++) {
            $('#tt' + i).append('<td></td>');
        }
    }
    // change or add color in the grid
    $('td').click(function addcolor() {
        colour = $('#colorPicker').val();
        if ($(this).attr('style')) {
            $(this).removeAttr('style');
            $(this).attr('style', 'background-color:' + colour);
        } else {
            $(this).attr('style', 'background-color:' + colour);
        }
    })
}
